﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiAplicacionArchivo
{
    public partial class frmArchivo : Form
    {

        const string PATH = "log.txt";

        public frmArchivo()
        {
            InitializeComponent();
            
                
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (txtPalabra.Text != "")
            {
                if (!File.Exists(PATH))
                    File.WriteAllText(PATH, txtPalabra.Text);
                else
                    File.AppendAllText(PATH, txtPalabra.Text);

            }
        }

        private void frmArchivo_Load(object sender, EventArgs e)
        {
            if (File.Exists(PATH))
                txtPalabra.Text = File.ReadAllText(PATH);
                    
        }
    }
}
