﻿using BusinessLogic;
using System;
using System.Windows.Forms;

namespace View
{
    /// <summary>
    /// Pantalla de autenticación.
    /// </summary>
    public partial class AuthForm : Form
    {
        public AuthForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Cierra el formulario.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
