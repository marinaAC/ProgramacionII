﻿using System;

namespace BusinessLogic
{
    /// <summary>
    /// Representa a un usuario externo a la empresa.
    /// </summary>
    public class Externo
    {
        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="nombre">Nombre de la persona.</param>
        /// <param name="cuenta">Nombre de la cuenta del usuario.</param>
        public Externo(string nombre, string cuenta)
        {

        }
    }
}
