﻿using System;
using System.IO;
using System.Xml.Serialization;

namespace BusinessLogic
{
    /// <summary>
    /// Serialización a XML.
    /// </summary>
    /// <typeparam name="T">Clase a serializar. Debe tener un constructor sin parámetros.</typeparam>
    public class Serializador
    {
        /// <summary>
        /// Ruta donde se guardará el archivo.
        /// </summary>
        private string ruta;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="ruta">Ruta donde se guardará el archivo.</param>
        public Serializador(string ruta)
        {
            this.ruta = ruta;
        }

    }
}
