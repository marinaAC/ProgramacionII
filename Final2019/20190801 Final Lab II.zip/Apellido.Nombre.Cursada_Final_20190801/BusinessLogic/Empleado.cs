﻿using System;

namespace BusinessLogic
{
    /// <summary>
    /// Representa a un Empleado.
    /// </summary>
    public class Empleado
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="nombre">Nombre de la persona.</param>
        /// <param name="cuenta">Nombre de cuenta del usuario.</param>
        /// <param name="clave">Clave del usuario.</param>
        /// <param name="areaTrabajo">Área de trabajo del empleado.</param>
        public Empleado(string nombre, string cuenta, string clave) 
        {
        }
    }
}
