﻿using System.Data.SqlClient;

namespace BusinessLogic
{
    /// <summary>
    /// Data Access Object para la tabla Usuarios de la base de datos Final.
    /// </summary>
    public class UsuarioDAO
    {
        /// <summary>
        /// Registra un usuario en la base de datos.
        /// </summary>
        /// <param name="usuario">Objeto usuario con nombre de cuenta y clave.</param>
        public static void Registrar(Usuario usuario)
        {
        }
        
    }
}
