﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessLogic
{
    /// <summary>
    /// Métodos de extensión.
    /// </summary>
    public static class Extension
    {
    }
}
