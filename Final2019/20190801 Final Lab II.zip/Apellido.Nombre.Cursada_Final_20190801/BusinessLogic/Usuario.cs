﻿using System.Xml.Serialization;

namespace BusinessLogic
{
    /// <summary>
    /// Representa a la cuenta de un usuario del sistema.
    /// </summary>
    [XmlInclude(typeof(Empleado))]
    [XmlInclude(typeof(Externo))]
    public class Usuario
    {
        /// <summary>
        /// Nombre de la cuenta.
        /// </summary>
        private string cuenta;
        /// <summary>
        /// Contraseña.
        /// </summary>
        private string clave;

        /// <summary>
        /// Nombre de la cuenta.
        /// </summary>
        public string Cuenta
        {
            get
            {
                return this.cuenta;
            }
            set
            {
                this.cuenta = value;
            }
        }

        /// <summary>
        /// Contraseña.
        /// </summary>
        public string Clave
        {
            get
            {
                return this.clave;
            }
            set
            {
                this.clave = value;
            }
        }
    }
}
