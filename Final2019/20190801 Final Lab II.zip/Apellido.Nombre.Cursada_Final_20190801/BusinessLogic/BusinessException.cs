﻿using System;

namespace BusinessLogic
{
    /// <summary>
    /// Excepción relacionada a la lógica de negocio.
    /// </summary>
    public class BusinessException
    {
        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="mensaje">Mensaje de la excepción.</param>
        public BusinessException(string mensaje)
        {

        }
    }
}
