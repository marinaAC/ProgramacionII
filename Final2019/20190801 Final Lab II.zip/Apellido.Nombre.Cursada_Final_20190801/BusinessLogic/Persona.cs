﻿namespace BusinessLogic
{
    /// <summary>
    /// Representa a una persona. No debe poderse instanciar, sólo heredar. 
    /// </summary>
    public class Persona
    {
        /// <summary>
        /// Nombre de la persona.
        /// </summary>
        private string nombre;
        
        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="nombre">Nombre de la persona.</param>
        public Persona(string nombre)
        {
            this.nombre = nombre;
        }
    }
}
